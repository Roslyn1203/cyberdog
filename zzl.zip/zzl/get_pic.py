import lcm
import toml
import sys
import os
import time
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from robot_control_cmd_lcmt import robot_control_cmd_lcmt
import cv2
import rclpy
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
import time

class ImageHandler:
    def __init__(self):
        self.bridge = CvBridge()
        self.image_received = False
        self.current_image = None
        self.timer_period = 0.1  # 0.1 seconds

    def image_callback(self, msg):
        self.current_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
        self.image_received = True

    def timer_callback(self):
        if self.image_received:
            display_image(self.current_image, "Image")
            self.image_received = False

def display_image(image, window_name="Image"):
    cv2.imshow(window_name, image)
    cv2.waitKey(0)  # Wait for a key press to close the window
    cv2.destroyAllWindows()

def main():
    # 创建图像处理程序并设置ROS订阅
    image_handler = ImageHandler()
    
    # 初始化ROS节点
    rclpy.init(args=None)
    node = rclpy.create_node('image_listener')
    qos_profile = QoSProfile(
        reliability=QoSReliabilityPolicy.BEST_EFFORT,
        history=QoSHistoryPolicy.KEEP_LAST,
        depth=10
    )
    subscription = node.create_subscription(
        Image,
        '/rgb_camera/image_raw',
        image_handler.image_callback,
        qos_profile
    )
    
    # 创建定时器
    timer = node.create_timer(image_handler.timer_period, image_handler.timer_callback)
    
    # 等待接收第一张图像
    while not image_handler.image_received:
        rclpy.spin_once(node)
    
    # 进入主循环
    rclpy.spin(node)

    # 清理资源
    node.destroy_timer(timer)
    node.destroy_subscription(subscription)
    rclpy.shutdown()

# 主函数
if __name__ == '__main__':
    main()

